public class QuickUnion implements UF {
    int p[];

    public QuickUnion(int n) {
        p = new int[n];
        for (var i = 0 ; i < n ; ++i) p[i] = i;
    }

    public int find(int a) {
        while (a != p[a]) a = p[a];
        return a;
    }

    public boolean union(int a, int b) {
        int pa = find(a);
        int pb = find(b);
        if (pa == pb) return false;
        p[pa] = pb;
        return true;
    }
    
}
