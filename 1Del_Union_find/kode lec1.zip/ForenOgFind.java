public class ForenOgFind implements UF {
    int p[], sz[];

    public ForenOgFind(int n) {
        p = new int[n];
        sz = new int[n];
        for (var i = 0 ; i < n ; ++i) {
            p[i] = i;
            sz[i] = 1;
        }
    }

    public int find(int a) {
        if (a == p[a]) return a;
        return p[a] = find(p[a]);
    }

    public boolean union(int a, int b) {
        int pa = find(a);
        int pb = find(b);
        if (pa == pb) return false;
        if (sz[pa] > sz[pb]) {
            p[pb] = pa;
            sz[pa] += sz[pb];
        } else {
            p[pa] = pb;
            sz[pb] += sz[pa];
        }
        return true;
    }
    
}
