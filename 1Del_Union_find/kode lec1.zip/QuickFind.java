public class QuickFind implements UF {
    int p[];

    public QuickFind(int n) {
        p = new int[n];
        for (var i = 0 ; i < n ; ++i) p[i] = i;
    }

    public int find(int a) {
        return p[a];
    }

    public boolean union(int a, int b) {
        if (p[a] == p[b]) return false;
        int pa = p[a];
        int pb = p[b];
        for (int i = 0 ; i < p.length ; ++i) {
            if (p[i] == pa) {
                p[i] = pb;
            }
        }
        return true;
    }
    
}
