public interface UF {
    int find(int a);
    boolean union(int a, int b);
    default boolean connected(int a, int b) {
        return find(a) == find(b);
    }
}